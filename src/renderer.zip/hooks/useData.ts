import * as api from '../services/api'
import { KnowledgeGraph } from '../types/types'
export default function useData() {
  const pptPrompt = `帮我把纯文字转成如下结构，这个结构代表的是一个PPT，有标题页、目录页、内容页，其中目录页中的内容按1、2、3...编写，内容页的数量也必须对照目录页。结构中的注释请在结果中忽略，xxx代表需要你填入的内容。

    xxx     //这部分应该填标题
    =====
    1.xxx  //这部分应该填入目录
    2.xxx
    3.xxx
    =====
    xxx    //这部分应该填入内容
    =====
    xxx    //这部分应该填入内容
    =====
    xxx    //这部分应该填入内容
    
    结果请放在名为pptData的es6模板字符串中
    
    纯文字如下：`

  const kgPrompt = `帮我将纯文字填入以下数据结构，我只需要数据结构数据。这个数据结构代表的是一个知识图谱，它包含结点数组和连接数组。注意结果只要json对象数据。
    interface KnowLedgeGraph{
      nodes:Node[]
      links:Link[]
    }
    type Node = {
      name: string
      id: number
    }
    type Link = {
      source: string
      target: string
    }
    
    请以json对象返回你的结果，要求符合以上结构
    
    纯文字如下：`

  const defaultKg: KnowledgeGraph = {
    nodes: [
      { name: '环境科学', id: 1 },
      { name: '大气污染', id: 2 },
      { name: '水污染', id: 3 },
      { name: '土壤污染', id: 4 },
      { name: '环境影响评价', id: 5 },
      { name: '环境法律法规', id: 6 },
      { name: '可持续发展', id: 7 },
      { name: '环保技术', id: 8 },
      { name: '环境监测', id: 9 },
      { name: '环境标志认证', id: 10 },
      { name: '环保产业', id: 11 },
    ],
    links: [
      { source: '环境科学', target: '大气污染' },
      { source: '环境科学', target: '水污染' },
      { source: '环境科学', target: '土壤污染' },
      { source: '环境科学', target: '环境影响评价' },
      { source: '环境科学', target: '环境法律法规' },
      { source: '环境科学', target: '可持续发展' },
      { source: '环境科学', target: '环保技术' },
      { source: '环境科学', target: '环境监测' },
      { source: '环境科学', target: '环境标志认证' },
      { source: '环境科学', target: '环保产业' },
    ],
  }
  const getPPTData = async (data: string) => {
    console.log('ppt')
    const result = await api.getPPTData(data)
    console.log(result)
    const start = result.indexOf('pptData = `') + 11
    const pptData = result.substring(start).trim()
    return pptData
  }
  const getKgData = async (data: string) => {
    console.log('kg')
    const result = await api.getKgData(data)
    console.log(result)
    const kgData = JSON.parse(result.replace(/\\/g, '\\\\'))
    return kgData
  }
  return {
    defaultKg,
    getPPTData,
    pptPrompt,
    kgPrompt,
    getKgData,
  }
}
