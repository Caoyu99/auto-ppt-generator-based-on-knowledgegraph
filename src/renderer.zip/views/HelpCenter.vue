<template>
    <div class="help-center">
    <n-button text class="back-link" @click="$router.push({ name: 'MainWindow' })">返回主页</n-button>
      <n-h1 prefix="bar">使用说明</n-h1>
      <n-text class="help-content">下面介绍如何使用本产品</n-text>
    </div>
  </template>
  
  <script setup lang="ts">
  </script>
  
  <style scoped>
  .help-center {
    display: flex;
    flex-direction: column;
    height: 100%;
  }
  /* .help-content{
    align-self:center;
  } */
  .back-link{
  position:absolute;
  left:10px;
  top:10px;
}
  </style>
  